package com.jcg.java.config;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.jcg.java.model.Employee;
import com.jcg.java.model.Hotel;

public class Dbimplementation {
	public ResultSet rsObj = null;
	public Statement stmtObj = null;
	public Connection connObj = null;
	MyDb db=new MyDb();
	
	

}
