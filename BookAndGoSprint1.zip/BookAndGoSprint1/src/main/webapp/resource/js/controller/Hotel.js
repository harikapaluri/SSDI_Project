var app = angular.module('myApp', []);
app.controller("hotelController", [ '$scope', '$http', function($scope, $http) {
$scope.message='Testing if hotel controller works';


}]);