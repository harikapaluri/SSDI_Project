package com.jcg.java.services;

import javax.servlet.annotation.WebServlet;

@WebServlet("/loginServlet")
public class LoginServlet {

}
