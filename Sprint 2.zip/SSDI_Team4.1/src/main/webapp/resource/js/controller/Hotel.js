angular.module('myApp.controllers').controller('hotelController', ['$scope', '$http', function($scope, $http){
debugger
}]);