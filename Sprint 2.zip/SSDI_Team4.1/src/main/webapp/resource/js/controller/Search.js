angular.
  bootstrap(document.getElementById("myApp"), ['Search']);